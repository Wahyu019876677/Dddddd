<?php
$id_telegram = "6774672055";
$id_botTele  = "7355599748:AAGVBH32vdm7dtYyz7il1pzdFJpOz0n6Fqw";
?>
